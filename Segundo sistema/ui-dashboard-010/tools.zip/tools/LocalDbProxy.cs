using System;
using System.IO;
using System.IO.Pipes;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace LocalDbProxy
{
    public static class Program
    {
        private static string _pipePath = "";

        public static int Main(string[] args)
        {
            string instance = args.Length > 0 ? args[0] : "MSSQLLocalDB";
            int port = args.Length > 1 ? int.Parse(args[1]) : 14333;

            StartLocalDb(instance);
            _pipePath = ResolvePipe(instance);
            if (string.IsNullOrWhiteSpace(_pipePath))
            {
                Console.Error.WriteLine("PIPE_NOT_FOUND");
                return 2;
            }

            var listener = new TcpListener(IPAddress.Loopback, port);
            listener.Start();
            Console.WriteLine("READY " + port + " " + _pipePath);
            Console.Out.Flush();

            while (true)
            {
                TcpClient client = listener.AcceptTcpClient();
                ThreadPool.QueueUserWorkItem(_ => HandleClient(client));
            }
        }

        private static void HandleClient(TcpClient client)
        {
            try
            {
                // pipe path like \\.\pipe\LOCALDB#xxx\tsql\query
                string name = _pipePath;
                const string prefix = @"\\.\pipe\";
                if (name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                {
                    name = name.Substring(prefix.Length);
                }

                using (client)
                using (var pipe = new NamedPipeClientStream(".", name, PipeDirection.InOut, PipeOptions.Asynchronous))
                {
                    pipe.Connect(10000);
                    NetworkStream tcp = client.GetStream();
                    Task t1 = tcp.CopyToAsync(pipe);
                    Task t2 = pipe.CopyToAsync(tcp);
                    Task.WaitAny(t1, t2);
                }
            }
            catch
            {
                try { client.Close(); } catch { }
            }
        }

        private static void StartLocalDb(string instance)
        {
            var psi = new ProcessStartInfo("sqllocaldb", "start " + instance)
            {
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };
            using (var p = Process.Start(psi))
            {
                if (p != null)
                {
                    p.WaitForExit(15000);
                }
            }
        }

        private static string ResolvePipe(string instance)
        {
            var psi = new ProcessStartInfo("sqllocaldb", "info " + instance)
            {
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };
            using (var p = Process.Start(psi))
            {
                string output = p.StandardOutput.ReadToEnd() + p.StandardError.ReadToEnd();
                p.WaitForExit(15000);
                var m = Regex.Match(output, @"np:(\\\\\.\\pipe\\[^\r\n]+)");
                if (m.Success)
                {
                    return m.Groups[1].Value.Trim();
                }
                m = Regex.Match(output, @"(\\\\\.\\pipe\\LOCALDB#[^\s\r\n]+)");
                return m.Success ? m.Groups[1].Value.Trim() : null;
            }
        }
    }
}
